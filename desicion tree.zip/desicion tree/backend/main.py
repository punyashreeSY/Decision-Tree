from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List
import ml_models

app = FastAPI(title="Decision Tree Comparison API")

# Configure CORS for frontend access
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allows all origins
    allow_credentials=True,
    allow_methods=["*"],  # Allows all methods
    allow_headers=["*"],  # Allows all headers
)

class PredictRequest(BaseModel):
    model_name: str
    features: List[float]

@app.get("/")
def read_root():
    return {"message": "Welcome to the Decision Tree Comparison API"}

@app.get("/features")
def get_features():
    """Return the list of feature names expected for the dataset"""
    return {"features": ml_models.get_feature_names()}

@app.get("/train/{model_name}")
def train_specific_model(model_name: str):
    """Train and evaluate a specific model"""
    try:
        results = ml_models.train_model(model_name)
        return results
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/compare")
def compare_all_models():
    """Train and evaluate all models and return comparison data"""
    try:
        results = ml_models.get_all_models_comparison()
        return {"models": results}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/predict")
def predict(request: PredictRequest):
    """Predict a single instance using a specific model"""
    try:
        # Check if length of features matches
        expected_len = len(ml_models.get_feature_names())
        if len(request.features) != expected_len:
            raise HTTPException(status_code=400, detail=f"Expected {expected_len} features, got {len(request.features)}")
            
        result = ml_models.predict_new_data(request.model_name, request.features)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
