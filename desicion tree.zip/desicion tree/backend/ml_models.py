import numpy as np
import pandas as pd
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from xgboost import XGBClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, confusion_matrix

# Load dataset once
data = load_breast_cancer()
X = pd.DataFrame(data.data, columns=data.feature_names)
y = data.target

# Split the data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Define models
models = {
    "id3": DecisionTreeClassifier(criterion="entropy", random_state=42),
    "cart": DecisionTreeClassifier(criterion="gini", random_state=42),
    "random_forest": RandomForestClassifier(random_state=42),
    "gradient_boosting": GradientBoostingClassifier(random_state=42),
    "xgboost": XGBClassifier(use_label_encoder=False, eval_metric='logloss', random_state=42)
}

# Dictionary to hold trained models
trained_models = {}

def get_feature_names():
    return data.feature_names.tolist()

def train_model(model_name: str):
    if model_name not in models:
        raise ValueError(f"Model {model_name} not found.")
    
    model = models[model_name]
    model.fit(X_train, y_train)
    trained_models[model_name] = model
    
    y_pred = model.predict(X_test)
    
    # Calculate metrics
    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred, zero_division=0)
    recall = recall_score(y_test, y_pred, zero_division=0)
    cm = confusion_matrix(y_test, y_pred).tolist()
    
    return {
        "accuracy": float(accuracy),
        "precision": float(precision),
        "recall": float(recall),
        "confusion_matrix": cm,
        "name": model_name
    }

def get_all_models_comparison():
    results = []
    for model_name in models.keys():
        res = train_model(model_name)
        results.append(res)
    return results

def predict_new_data(model_name: str, features: list):
    if model_name not in trained_models:
        # Train it if it hasn't been trained yet
        train_model(model_name)
        
    model = trained_models[model_name]
    # Input format should be 2D array
    features_array = np.array([features])
    prediction = model.predict(features_array)
    class_index = int(prediction[0])
    
    return {
        "prediction": class_index,
        "class_name": data.target_names[class_index]
    }
