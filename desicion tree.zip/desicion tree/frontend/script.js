const API_BASE_URL = 'http://localhost:8000';
let currentChart = null;
let datasetFeatures = [];

// DOM Elements
const viewContainer = document.getElementById('dynamic-view');
const pageTitle = document.getElementById('page-title');
const navLinks = document.querySelectorAll('.nav-links li:not(.separator)');
const loader = document.getElementById('loader');

// Templates
const modelTemplate = document.getElementById('model-view-template');
const compareTemplate = document.getElementById('compare-view-template');
const predictTemplate = document.getElementById('predict-view-template');

// Initialize App
document.addEventListener('DOMContentLoaded', () => {
    fetchFeatures();
    // Default load ID3
    navigateTo('id3', 'ID3 Model');
});

// Navigation function
function navigateTo(target, title) {
    // Update active state
    navLinks.forEach(link => {
        if(link.dataset.target === target) {
            link.classList.add('active');
        } else {
            link.classList.remove('active');
        }
    });

    pageTitle.textContent = title;
    
    // Clear current view
    viewContainer.innerHTML = '';
    
    // Destroy chart if exists
    if(currentChart) {
        currentChart.destroy();
        currentChart = null;
    }

    if(target === 'compare') {
        const clone = compareTemplate.content.cloneNode(true);
        viewContainer.appendChild(clone);
        // Automatically fetch comparison if desired, or let user click button
        compareAllModels();
    } else if(target === 'predict') {
        const clone = predictTemplate.content.cloneNode(true);
        viewContainer.appendChild(clone);
        setupPredictForm();
    } else {
        const clone = modelTemplate.content.cloneNode(true);
        viewContainer.appendChild(clone);
        // Set current model id
        viewContainer.dataset.currentModel = target;
        trainCurrentModel();
    }
}

function showLoader() {
    loader.style.display = 'block';
    viewContainer.style.opacity = '0.5';
}

function hideLoader() {
    loader.style.display = 'none';
    viewContainer.style.opacity = '1';
}

// Fetch available features from backend
async function fetchFeatures() {
    try {
        const response = await fetch(`${API_BASE_URL}/features`);
        const data = await response.json();
        datasetFeatures = data.features;
    } catch(err) {
        console.error('Error fetching features:', err);
    }
}

// Train specific model
async function trainCurrentModel() {
    const modelId = viewContainer.dataset.currentModel;
    if(!modelId) return;

    showLoader();
    try {
        const response = await fetch(`${API_BASE_URL}/train/${modelId}`);
        const data = await response.json();
        
        // Update UI
        document.getElementById('val-accuracy').textContent = (data.accuracy * 100).toFixed(2) + '%';
        document.getElementById('val-precision').textContent = (data.precision * 100).toFixed(2) + '%';
        document.getElementById('val-recall').textContent = (data.recall * 100).toFixed(2) + '%';
        
        // Update CM
        const cmGrid = document.getElementById('cm-grid');
        cmGrid.innerHTML = '';
        data.confusion_matrix.forEach(row => {
            row.forEach(cellValue => {
                const div = document.createElement('div');
                div.className = 'cm-cell';
                div.textContent = cellValue;
                cmGrid.appendChild(div);
            });
        });
    } catch(err) {
        console.error('Error training model:', err);
        alert('Failed to connect to backend. Make sure FastAPI is running.');
    } finally {
        hideLoader();
    }
}

// Compare all models
async function compareAllModels() {
    showLoader();
    try {
        const response = await fetch(`${API_BASE_URL}/compare`);
        const data = await response.json();
        
        const models = data.models;
        const labels = models.map(m => formatName(m.name));
        const accData = models.map(m => (m.accuracy * 100).toFixed(2));
        const precData = models.map(m => (m.precision * 100).toFixed(2));
        
        // Populate Table
        const tbody = document.getElementById('comparison-table-body');
        if(tbody) {
            tbody.innerHTML = '';
            models.forEach(m => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td><strong>${formatName(m.name)}</strong></td>
                    <td>${(m.accuracy * 100).toFixed(2)}%</td>
                    <td>${(m.precision * 100).toFixed(2)}%</td>
                    <td>${(m.recall * 100).toFixed(2)}%</td>
                `;
                tbody.appendChild(tr);
            });
        }
        
        // Render Chart
        const ctx = document.getElementById('comparisonChart').getContext('2d');
        if(currentChart) currentChart.destroy();
        
        currentChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [
                    {
                        label: 'Accuracy (%)',
                        data: accData,
                        backgroundColor: 'rgba(59, 130, 246, 0.7)',
                        borderColor: 'rgb(59, 130, 246)',
                        borderWidth: 1
                    },
                    {
                        label: 'Precision (%)',
                        data: precData,
                        backgroundColor: 'rgba(16, 185, 129, 0.7)',
                        borderColor: 'rgb(16, 185, 129)',
                        borderWidth: 1
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        },
                        ticks: { color: '#94a3b8' }
                    },
                    x: {
                        grid: { display: false },
                        ticks: { color: '#94a3b8' }
                    }
                },
                plugins: {
                    legend: {
                        labels: { color: '#f8fafc' }
                    }
                }
            }
        });
        
    } catch(err) {
        console.error('Error comparing models:', err);
    } finally {
        hideLoader();
    }
}

// Setup predict form with dynamic inputs based on dataset features
function setupPredictForm() {
    const featuresContainer = document.getElementById('features-inputs');
    if(!featuresContainer) return;
    
    featuresContainer.innerHTML = '';
    
    if(datasetFeatures.length === 0) {
        featuresContainer.innerHTML = '<p>Error loading features...</p>';
        return;
    }

    // Create an input for every feature
    datasetFeatures.forEach((feature, index) => {
        const fg = document.createElement('div');
        fg.className = 'form-group';
        
        const label = document.createElement('label');
        label.textContent = formatFeatureName(feature);
        label.title = feature;
        
        const input = document.createElement('input');
        input.type = 'number';
        input.step = 'any';
        input.required = true;
        input.id = `feat_${index}`;
        // Set some default dummy values roughly in range to make it easier for user
        input.value = (Math.random() * 10).toFixed(2);
        
        fg.appendChild(label);
        fg.appendChild(input);
        featuresContainer.appendChild(fg);
    });

    const form = document.getElementById('predict-form');
    form.addEventListener('submit', handlePredictSubmit);
}

async function handlePredictSubmit(e) {
    e.preventDefault();
    
    const modelName = document.getElementById('model-select').value;
    const features = [];
    
    datasetFeatures.forEach((_, index) => {
        const val = parseFloat(document.getElementById(`feat_${index}`).value);
        features.push(val);
    });
    
    const resultDiv = document.getElementById('prediction-result');
    resultDiv.innerHTML = '<div class="loader" style="display:block; position:relative;"></div>';
    resultDiv.className = 'prediction-result';

    try {
        const response = await fetch(`${API_BASE_URL}/predict`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                model_name: modelName,
                features: features
            })
        });
        
        if(!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.detail || 'Failed to predict');
        }
        
        const data = await response.json();
        
        // Show result visually
        const className = data.class_name;
        resultDiv.textContent = className.toUpperCase();
        
        if(className.toLowerCase() === 'malignant') {
            resultDiv.classList.add('malignant');
        } else {
            resultDiv.classList.add('benign');
        }
        
    } catch(err) {
        resultDiv.textContent = `Error: ${err.message}`;
        resultDiv.style.color = '#ef4444';
        console.error(err);
    }
}

// Utils
function formatName(name) {
    return name.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
}

function formatFeatureName(name) {
    // Simplify "mean radius" -> "Mean Radius"
    return name.split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
}
